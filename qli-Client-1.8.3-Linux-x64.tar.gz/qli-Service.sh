﻿#!/bin/bash

cd /q
/q/qli-Client -service
